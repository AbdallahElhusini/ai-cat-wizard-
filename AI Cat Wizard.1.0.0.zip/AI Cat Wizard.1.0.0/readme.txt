=== AI Cat Wizard ===
Contributors: abdallahelhussini
Tags: content, automation, AI, artificial intelligence, blog, post, posting, automate, social media, generate, generator, chatgpt, openai, gpt, natural language,content generator
Requires at least: 4.7
Tested Up To: 6.1.1
Stable tag: 1.0
License: GPLv2 
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

AI Cat Wizard revolutionizes content creation by integrating OpenAI's advanced GPT-3 technology into your WordPress website. The features of AI Cat Wizard include:

Content Generation: Generate unique, AI-written content for posts and pages with a user-friendly interface. Simply provide a topic, select some parameters, and let the AI create engaging content for you.
WooCommerce Helper: Streamline your product description process with AI. AI Cat Wizard can generate detailed, engaging product descriptions automatically.
Social Media Helper: Create compelling social media posts in a matter of seconds. AI Cat Wizard helps you maintain an active social media presence with less effort.
== Installation ==

Purchase AI Cat Wizard from the CodeCanyon marketplace.
Download the plugin files and upload them to the /wp-content/plugins/Wizardai directory, or install the plugin through the WordPress plugins screen directly.
Activate the plugin through the 'Plugins' screen in WordPress.
Go to the Settings->WizardAI screen to configure the plugin.
Enter your OpenAI API key and start generating content!
== Frequently Asked Questions ==

= What is the OpenAI API key and how do I get it? =

The OpenAI API key is a code that allows the AI Cat Wizard plugin to connect to OpenAI's GPT-3 engine. You can get it by signing up at OpenAI's website.

= Is this a one-time purchase? =

Please check the product page on CodeCanyon for pricing details.

== Screenshots ==

Screenshot of the content generator.
Screenshot of the WooCommerce helper.
Screenshot of the social media helper.
== Changelog ==

= 1.0 =

Initial release.
== License ==

AI Content Generator For Elementor - OpenAI ChatGPT is released under the GNU General Public License version 2 or later (GPLv2+).

License URI: http://www.gnu.org/licenses/gpl-2.0.html