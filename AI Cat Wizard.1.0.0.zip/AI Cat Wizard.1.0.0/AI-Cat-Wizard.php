<?php
/*
Plugin Name: AI Cat Wizard 
Version: 1.0.0
Description: The AI Cat Wizard is a powerful plugin for WordPress that streamlines the content creation process, saving you time and effort. This plugin taps into the power of OpenAI’s ChatGPT-3 system to generate entire articles based on any topic you input. CAT is also great for brainstorming and will help you select SEO optimized article titles, and is also smart enough to output content preformatted with optimized headers and sub-headings. You’ll also love the Social Helper feature which generates short summaries of any blog post along with recommended hashtags and a direct post link. Everything you need to help streamline your social media promotions. Simply enter your own API key available for free from OpenAI and start generating content today!
Author: Abdallah ElHussini
Tags: content, automation, AI, artificial intelligence, blog, post, posting, automate, social media, generate, generator, chatgpt, openai, gpt, natural language,content generator
Minimum WordPress Version: 4.7
Tested Up To: 6.1.1
License: GPLv2
*/


function Wizardai_add_admin_menu() {
    add_menu_page(
        'AI Cat Wizard',
        'AI Cat Wizard',
        'manage_options',
        'Wizardai-settings',
        'Wizardai_settings_page',
        plugin_dir_url(__FILE__) . 'icon.png',
        20
    );
        add_submenu_page(
            'Wizardai-settings',
            'Settings',
            'Settings',
            'manage_options',
            'Wizardai-settings',
            'Wizardai_settings_page'
        );
        add_submenu_page(
        'Wizardai-settings',
        'Content Generator',
        'Content Generator',
        'manage_options',
        'Wizardai_generator_content',
        'Wizardai_generator_content'
        );

        add_submenu_page(
        'Wizardai-settings',
        'Social Media Helper',
        'Social Media Helper',
        'manage_options',
        'Wizardai-social-media-helper',
        'Wizardai_social_media_helper'
        );
        add_submenu_page(
        'Wizardai-settings',
        'Woocommerce Helper',
        'Woocommerce Helper',
        'manage_options',
        'Wizardai_woocommerce_helper',
        'Wizardai_woocommerce_helper'
        );
        add_submenu_page(
        'Wizardai-settings',
        'Instructions',
        'Instructions',
        'manage_options',
        'Wizardai-instructions',
        'Wizardai_instructions_page'
        );


}

add_action( 'admin_menu', 'Wizardai_add_admin_menu' );

function Wizardai_settings_page() {
    ?>
<div class="Wizardsettingsform">
    <h1>AI Cat Wizard - Settings</h1>
    <?php settings_errors(); ?>
    <form method="post" action="options.php" class="Wizardapisettingsform">
    <?php
        settings_fields( 'Wizardai_settings_group' );
        do_settings_sections( 'AI-Cat-Wizard' );
        submit_button();
    ?>
</form>
</div>
<?php
}


function Wizardai_add_settings_section() {
add_settings_section(
'Wizardai_settings_section',
'OpenAI API Settings',
'Wizardai_settings_section_cb',
'AI-Cat-Wizard'
);
}
add_action( 'admin_init', 'Wizardai_add_settings_section' );

function Wizardai_settings_section_cb() {
    echo '<div class="Wizardai-generated-message">Enter your OpenAI API key to use AI Cat Wizard. If you don\'t have one, you can <a href="https://beta.openai.com/signup/api-key" target="_blank">sign up for one here</a>.</div>';
    }

function Wizardai_add_settings_field() {
add_settings_field(
'Wizardai_api_key',
'API Key',
'Wizardai_api_key_cb',
'AI-Cat-Wizard',
'Wizardai_settings_section'
);
register_setting( 'Wizardai_settings_group', 'Wizardai_api_key', 'Wizardai_validate_api_key' );
}
add_action( 'admin_init', 'Wizardai_add_settings_field' );

function Wizardai_api_key_cb() {
?>
<input class="regular-text" type="text" name="Wizardai_api_key" placeholder="Enter your OpenAI API key here" value="<?php echo sanitize_text_field(get_option( 'Wizardai_api_key' )); ?>">

<?php
}

function Wizardai_validate_api_key( $api_key ) {
    $api_key = sanitize_text_field($api_key);
    if ( empty( $api_key ) ) {
        add_settings_error(
            'Wizardai_api_key',
            'Wizardai_api_key_error',
            'API Key field is required',
            'error'
        );
        return '';
    }

    $validation_url = esc_url_raw( 'https://api.openai.com/v1/engines/davinci/completions' );
    $data = array(
        'prompt' => sanitize_text_field( 'What is the capital of France?' ),
    );
    
    $headers = array(
        'Content-Type'  => 'application/json',
        'Authorization' => 'Bearer ' . $api_key
    );    

    $response = wp_remote_post( $validation_url, array(
        'headers' => $headers,
        'body'    => wp_json_encode($data),
    ) ); 

    $response_code = wp_remote_retrieve_response_code( $response );

    if ( is_wp_error( $response ) || $response_code !== 200 ) {
        add_settings_error(
            'Wizardai_api_key',
            'Wizardai_api_key_error',
            'Invalid API Key',
            'error'
        );
        return '';
    }

    add_settings_error(
        'Wizardai_api_key',
        'Wizardai_api_key_success',
        'API Key is valid',
        'updated'
    );
    return sanitize_text_field( $api_key );
}

//End of Plugin Settings Page


//Start of code for the article generator

function Wizardai_generator_content() {

    $api_key = get_option( 'Wizardai_api_key' );
    if ( empty( $api_key ) ) {
        echo '<div class="Wizardai-generator-content">';
        echo '<h1>AI Cat Wizard - Generator Content</h1>';
        echo '<p class="noapimessage">You need to enter a valid OpenAI API key before using the Content Generator. Please visit the <a href="admin.php?page=Wizardai-settings">settings page</a> or <a href="https://beta.openai.com/signup/" target="_blank">signup for a new key</a>.</p>';
        echo '</div>';
        } else {

  ?>

<div class="Wizardai-generator-content">
  <h1>AI Cat Wizard - Generator Content</h1>
    <form method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ); ?>" id="Wizardai_form" class="Wizardai-form">
        <label for="topic">Please enter a topic:</label><br>
        <input type="text" id="topic" name="topic" placeholder="Enter a topic here">
        <br>
        <label for="headers">Please enter the number of headlines:</label><br>
        <input type="text" id="headers" name="headers" placeholder="Enter a number here">
        <br>
        <label for="type">Please select type of the content:</label><br>
        <select id="type" name="type">
            <option value="post">Post</option>
            <option value="page">Page</option>
        </select>
        <br>
        <label for="language">Please select a language:</label><br>
        <select id="language" name="language">
            <option value="English">English</option>
            <option value="Spanish">Spanish</option>
            <option value="French">French</option>
            <option value="German">German</option>
            <option value="Arabic">Arabic</option>
        </select>
        <br>
        <label for="status">Please select the post status:</label><br>
        <select id="status" name="status">
            <option value="publish">Publish</option>
            <option value="draft">Draft</option>
        </select>
        <br>
        <label for="tone">Please select tone of the writing:</label><br>
        <select id="tone" name="tone">
            <option value="formal">Formal</option>
            <option value="casual">Casual</option>
            <option value="friendly">Friendly</option>
        </select>
        <br>
        <div class="slidecontainer">
            <label for="wordcount">Please specify the number of words:</label><br>
            <input type="range" id="wordcount" name="wordcount" min="50" max="2500" value="1250" class="sliderRange" >
            <span id="wordcount_value">1250</span>
        </div>

<br>
  <br>
        <input type="submit" id="Wizardai_submit" class="Wizardai-generate-btn" value="Generate Content">
    </form>

</div>
      <script>
    document.getElementById("wordcount").addEventListener("input", function() {
        document.getElementById("wordcount_value").innerText = this.value;
    });
    </script>
  <?php
if ( isset( $_POST['topic'] ) && isset($_POST['headers']) && isset($_POST['type']) && isset($_POST['language']) ) {
            $topic = sanitize_text_field( $_POST['topic'] );
            $wordcount = sanitize_text_field( $_POST['wordcount'] );
            $headers = intval( $_POST['headers'] );
            $language = sanitize_text_field($_POST['language']);
            $type = sanitize_text_field( $_POST['type'] );
            $api_key = get_option('Wizardai_api_key');
            $tone = sanitize_text_field( $_POST['tone'] );
            $prompt = 'Please write me a ' . esc_html($tone) . ', ' . esc_html($type) . ' about: ' . esc_html($topic) . 'all content in ' . esc_html($language) . ' with approximately words and ' . esc_html($headers) . ' SEO optimized headings and subheadings before each paragraph of the content as appropriate and wrapped in html tags for H2 and H3 as appropriate but do not use H1 tags.';

            $temperature = 0.7;
            $max_tokens = 4000;
            $url = 'https://api.openai.com/v1/engines/text-davinci-003/completions';
        
            $response = wp_remote_post( $url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . esc_html($api_key),
                    'Content-Type'  => 'application/json'
                ],
                'timeout' => 600, 
                'body' => json_encode( [
                    'prompt' => $prompt,
                    'max_tokens' => $max_tokens,
                    'temperature' => $temperature
                ])
            ]);
        
            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            $content = $data['choices'][0]['text'];

            $content_type = 'post';
            if ( $_POST['type'] === 'page' ) {
                $content_type = 'page';
            }
            $status = sanitize_text_field( $_POST['status'] );
            $wordcount = intval( $_POST['wordcount'] );

            $post_id = wp_insert_post( [
                'post_title'   => $topic,
                'post_content' => $content,
                'post_status'  => $status,
                'post_type'    => $content_type,
            ] );

            if ( is_wp_error( $post_id ) ) {
                echo '<p>There was an error generating the post/page</p>';
            } else {
echo '<div class="toast wizardai-toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
          <strong class="mr-auto">WizardAI</strong>
          <small>Just Now</small>
          <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="toast-body">
          Successfully generated a new ' . $content_type . ': <a href="' . get_permalink( $post_id ) . '">' . get_the_title( $post_id ) . '</a>.
        </div>
      </div></div>';
            }

            
        }
    }
}

add_shortcode( 'Wizardai_generator_content', 'Wizardai_generator_content' );




function Wizardai_social_media_helper() {
    // Initialize the results
    $results_summary = '';
    $results_hashtags = '';
    $results_posts = '';

    $posts_query = new WP_Query( array(
        'post_type' => array('post', 'page'),
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC'
    ) );

    ?>
    <div class="Wizardai-social-helper">
        <h1>AI Cat Wizard - Social Helper</h1>
        <form method="post" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ); ?>" id="Wizardai_social_helper_form" class="Wizardai-form">
            <label for="post_id">Select a post to generate summary and hashtags:</label>
            <select name="post_id" id="post_id">
                <?php
                if ( $posts_query->have_posts() ) :
                    while ( $posts_query->have_posts() ) : $posts_query->the_post();
                        echo '<option value="' . get_the_ID() . '">' . get_the_title() . '</option>';
                    endwhile;
                    wp_reset_postdata();
                else:
                    echo '<option value="0">No posts found</option>';
                endif;
                ?>
            </select>
            <input type="submit" value="Generate Summary and Hashtags" class="Wizardai-generate-btn">
            <label for="platforms">Select social media platforms:</label>
            <div id="platforms">
        <fieldset>
            <legend>Select social media platforms:</legend>
            <input type="checkbox" name="platforms[]" value="facebook"> Facebook<br>
            <input type="checkbox" name="platforms[]" value="twitter"> Twitter<br>
            <input type="checkbox" name="platforms[]" value="linkedin"> LinkedIn<br>
        </fieldset>

            </div>
            <div id="characterLimits"></div>
            <div class="spinner" id="loadingSpinner"></div>

        </form>
    </div>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script>
    // Function to copy text from an element to the clipboard
    function copyToClipboard(id) {
        var text = document.getElementById(id).innerText;
        var textarea = document.createElement("textarea");
        textarea.textContent = text;
        textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
        document.body.appendChild(textarea);
        textarea.select();
        try {
            return document.execCommand("copy");  // Security exception may be thrown by some browsers.
        } catch (ex) {
            console.warn("Copy to clipboard failed.", ex);
            return false;
        } finally {
            document.body.removeChild(textarea);
        }
    }

    // Function to control the visibility of the summary and hashtags sections
    document.addEventListener("DOMContentLoaded", function() {
        var summaryOutput = document.getElementById("summary-output");
        var hashtagsOutput = document.getElementById("hashtags-output");

        if (summaryOutput.innerText.trim() === '') {
            document.getElementById("summary-section").style.display = 'none';
        }

        if (hashtagsOutput.innerText.trim() === '') {
            document.getElementById("hashtags-section").style.display = 'none';
        }
    });
</script>



    <?php
    if ( isset( $_POST['post_id'] ) ) {
        $post_id = intval( $_POST['post_id'] );
        if ($post_id === 0) {
            echo 'Error: Please select a post';
            return;
        }
	
        $post = get_post( $post_id );

        if ( $post ) {
            $post_title = $post->post_title;
            $post_content = $post->post_content;
            $current_url = get_permalink($post_id);

            // ... Code to get the API Key and Post details ...
$summary_prompt = "Please summarize the following text:\n" . wp_strip_all_tags( $post_content );
$summary_response = call_openai_api($summary_prompt, 0.3, 150);

if ( is_wp_error( $summary_response ) ) {
    echo 'Error: ' . esc_html( $summary_response->get_error_message() );
    return;
} else {
    $summary_result = json_decode( wp_remote_retrieve_body( $summary_response ), true );
    if ( isset( $summary_result['error'] ) ) {
        echo 'Error: ' . esc_html( $summary_result['error']['message'] );
    } else {
        $summary = $summary_result['choices'][0]['text'];
    }
}
		}
$selected_platforms = isset($_POST['platforms']) ? $_POST['platforms'] : array();

if (empty($selected_platforms)) {
    echo 'Error: Please select at least one social media platform';
    return;
}

// Generate hashtags based on the post title
$hashtags = Wizardai_generate_hashtags($post_title);

if (empty($hashtags)) {
    echo 'Error: Failed to generate hashtags';
    return;
}
// Combine the summary and hashtags
$summary_and_hashtags = $summary . " " . implode(" ", $hashtags);

$results_summary = $summary;
$results_hashtags = implode(" ", $hashtags);

$results_posts .= '<h2>Generated Social Media Posts:</h2>';

// Generate social media posts and links for each platform
foreach ($selected_platforms as $platform) {
    // Create a post for the platform
    $post_for_platform = trim_summary_based_on_platform_limit($summary_and_hashtags, $platform);
    
    // Generate a share link for the platform
    $share_link = generate_share_link($post_for_platform, $current_url, $platform);

    if (empty($share_link)) {
        $results_posts .= 'Error: Failed to generate share link for ' . ucfirst($platform);
        continue;
    }

  // Add the post and share link to the results
    $results_posts .= '<div class="generated-post">';
    $results_posts .= '<h3>' . ucfirst($platform) . ' Post:</h3>';
    $results_posts .= '<p>' . $post_for_platform . '</p>';
	$results_posts .= '<a class="share-link" href="' . $share_link . '" target="_blank">Share to ' . ucfirst($platform) . '</a>';
    $results_posts .= '</div>';
    }
    }
	    // Now output the form, which includes the results
    ?>
    <div class="Wizardai-social-helper">
        <!-- ... The form ... -->
    <div id="summary-section">
        <h3>Summary:</h3>
        <p id="summary-output"><?php echo $results_summary; ?></p>
        <button id="copy-summary-btn" onclick="copyToClipboard('summary-output')" class="Wizardai-copy-btn">Copy Summary</button>
    </div>
    <div id="hashtags-section">
        <h3>Hashtags:</h3>
        <p id="hashtags-output"><?php echo $results_hashtags; ?></p>
        <button id="copy-hashtags-btn" onclick="copyToClipboard('hashtags-output')" class="Wizardai-copy-btn">Copy Hashtags</button>
    </div>
        <?php echo $results_posts; ?>
    </div>
    <?php

}
function call_openai_api($prompt, $temperature, $max_tokens) {
    $api_key = get_option('Wizardai_api_key');
    $api_url = 'https://api.openai.com/v1/engines/text-davinci-003/completions';

    $response = wp_remote_post( $api_url, array(
        'method' => 'POST',
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ),
        'body' => json_encode( array(
            'prompt' => $prompt,
            'temperature' => $temperature,
            'max_tokens' => $max_tokens
        )),
        'timeout' => 60000
    ) );

    return $response;
}

function trim_summary_based_on_platform_limit($summary, $platform) {
    $character_limits = array(
        'facebook' => 63206,
        'twitter' => 280,
        'linkedin' => 1300,
        'instagram' => 2200
    );

    $limit = isset($character_limits[$platform]) ? $character_limits[$platform] : null;

    if ($limit !== null) {
        return mb_strimwidth($summary, 0, $limit, '...');
    }

    return $summary;
}
function Wizardai_generate_hashtags($post_title) {
    $api_key = get_option('Wizardai_api_key');
    $hashtag_prompt = "Generate 10 relevant and popular hashtags for a social media post about the following topic: {$post_title}";
    $hashtag_temperature = 0.6;
    $hashtag_max_tokens = 50;
    $hashtag_url = 'https://api.openai.com/v1/engines/text-davinci-003/completions';

    $hashtag_response = wp_remote_post( $hashtag_url, array(
        'method' => 'POST',
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ),
        'body' => json_encode( array(
            'prompt' => $hashtag_prompt,
            'temperature' => $hashtag_temperature,
            'max_tokens' => $hashtag_max_tokens
        )),
        'timeout' => 60000
    ) );

if ( is_wp_error( $hashtag_response ) ) {
    echo 'Error: ' . esc_html( $hashtag_response->get_error_message() );
    return array();
} else {
    $hashtag_result = json_decode( wp_remote_retrieve_body( $hashtag_response ), true );
 if ( isset( $hashtag_result['error'] ) ) {
        echo 'Error: ' . esc_html( $hashtag_result['error']['message'] );
        return array();
    } else {
        $hashtags_text = $hashtag_result['choices'][0]['text'];
        $hashtags = explode(',', $hashtags_text);
        return array_map('trim', $hashtags);
    } }
}
function generate_share_link($post, $url, $platform) {
    $post = urlencode($post);
    $url = urlencode($url);

    switch ($platform) {
        case 'facebook':
            return 'https://www.facebook.com/sharer/sharer.php?u=' . $url;
        case 'twitter':
            return 'https://twitter.com/intent/tweet?text=' . $post . '&url=' . $url;
        case 'linkedin':
            return 'https://www.linkedin.com/shareArticle?mini=true&url=' . $url . '&summary=' . $post;
        case 'instagram':
            // Instagram does not support direct link sharing
            return '';
        default:
            return '';
    }
}

function Wizardai_woocommerce_helper() {
    $products_query = new WP_Query( array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC'
    ) );
	
	$product_id = $_POST['product_id'] ?? '';
    $new_description = $_POST['new_description'] ?? '';
	
if ( isset( $_POST['product_id'], $_POST['action'] ) ) {
    $product_id = intval( $_POST['product_id'] );
    $product = wc_get_product( $product_id );

    if ( $product ) {
        if ( $_POST['action'] == 'Generate Product Description' ) {
            $product_title = $product->get_title();
            $product_description = $product->get_description();

            $api_key = get_option('Wizardai_api_key');
            $description_prompt = "Please generate a new product description for the following product:\nProduct: " . $product_title . "\n\nExisting Description: " . wp_strip_all_tags( $product_description );
            $description_temperature = 0.3;
            $description_max_tokens = 150;
            $description_url = 'https://api.openai.com/v1/engines/text-davinci-003/completions';

            $description_response = wp_remote_post( $description_url, array(
                'method' => 'POST',
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key
                ),
                'body' => json_encode( array(
                    'prompt' => $description_prompt,
                    'temperature' => $description_temperature,
                    'max_tokens' => $description_max_tokens
                )),
                'timeout' => 60000
            ) );

			if( is_wp_error( $description_response ) ) {
				echo 'Error: ' . esc_html( $description_response->get_error_message() );
			} else {
				$description_result = json_decode( wp_remote_retrieve_body( $description_response ), true );
				$new_description = $description_result['choices'][0]['text'];
				echo '<script>document.getElementById("new_description").value = ' . json_encode($new_description) . '; document.getElementById("confirm-btn").disabled = false;</script>';
			}

        } elseif ( $_POST['action'] == 'Confirm' && isset($_POST['new_description']) ) {
    // Save the new description to the product
    $new_description = $_POST['new_description'];
    $product->set_description( $new_description );
    $product->save();
    
    $product_link = get_permalink($product_id);
    echo '<div class="success-message"><p>New description saved to the product. You can view it <a href="' . esc_url($product_link) . '" target="_blank">here</a>.</p></div>';
        }
    } else {
        echo 'Invalid product ID. Please try again.';
    }
}
    ?>
    <div class="Wizardai-woocommerce-helper">
        <h1>AI Cat Wizard - WooCommerce Helper</h1>
        <form method="post" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" id="Wizardai_woocommerce_helper_form" class="Wizardai-form">
            <label for="product_id">Select a product to generate a new description:</label>
            <select name="product_id" id="product_id">
                <?php
                if ($products_query->have_posts()) :
                    while ($products_query->have_posts()) : $products_query->the_post();
                        echo '<option value="' . get_the_ID() . '"' . (get_the_ID() == $product_id ? ' selected' : '') . '>' . get_the_title() . '</option>';
                    endwhile;
                    wp_reset_postdata();
                else :
                    echo '<option value="">No products found</option>';
                endif;
                ?>
            </select>

            <label for="new_description">New Description:</label>
            <textarea name="new_description" id="new_description"><?php echo esc_textarea($new_description); ?></textarea>
            
            <input type="submit" name="action" value="Generate Product Description" class="Wizardai-generate-btn">
            <input type="submit" name="action" value="Confirm" class="Wizardai-confirm-btn" <?php echo $new_description ? '' : 'disabled'; ?>>
        </form>
    </div>
<script>
function autoResizeTextArea() {
    var textArea = document.getElementById("new_description");

    textArea.addEventListener('input', function() {
        // Temporarily reset the height to 'auto' to properly calculate the new height
        this.style.height = 'auto';

        // Set the height to the scrollHeight plus a little extra to avoid content cut-off
        this.style.height = (this.scrollHeight + 2) + 'px'; // the "2" here accounts for the border thickness
    }, false);
}

// Call the function once the document has finished loading
document.addEventListener('DOMContentLoaded', autoResizeTextArea);
</script>

    <?php

}

function Wizardai_instructions_page() {
    ?>
    <style>
        .wrap {
            max-width: 800px;
            margin: 0 auto;
        }
        .wrap h2 {
            color: #0073aa;
            margin-top: 30px;
        }
        .wrap p {
            line-height: 1.6;
            margin-bottom: 20px;
        }
    </style>

    <div class="wrap">
        <h1>Welcome to AI Cat Wizard!</h1>
        <p>This plugin leverages the power of OpenAI's GPT-4 model to assist with content creation, social media posts, and WooCommerce product descriptions. Follow the instructions below to make the most out of this tool.</p>
        
        <h2>API Key Setup</h2>
        <p>To start, enter your OpenAI API key in the settings. This key allows the plugin to connect to OpenAI's API and generate creative text.</p>

        <h2>Content Generator</h2>
        <p>With a valid API key, you can generate unique articles for posts or pages. Navigate to 'Content Generator' in the menu, input the desired topic, select parameters like language, content type, tone, and word count, then click 'Generate Content'.</p>

        <h2>Social Media Helper</h2>
        <p>The Social Media Helper generates short text suitable for social media posts. Go to 'Social Media Helper' in the menu, enter a topic, and generate social media text. Review, select, and copy your preferred output to use in your social media platforms.</p>
        
        <h2>WooCommerce Helper</h2>
        <p>If you're running a WooCommerce store, the WooCommerce Helper can generate product descriptions for you. Navigate to 'WooCommerce Helper', select a product, and generate a new description. Remember to confirm and save the new description to your product.</p>
        
        <h2>Post Editing and Publishing</h2>
        <p>The generated content is initially saved as a draft. Review, make any necessary edits, and publish when ready. The Social Media and WooCommerce helpers also allow you to review and edit the generated content before saving or using them.</p>
        
        <h2>Happy Creating!</h2>
        <p>With AI Cat Wizard, creating engaging content is a breeze. Should you encounter any issues or have suggestions, feel free to contact support. Happy creating!</p>
    </div>
    <?php
}


function Wizardai_enqueue_styles() {
    wp_enqueue_style(
        'wizardai-style',
        plugins_url( 'css/wizardai-style.css', __FILE__ ) 
    );
}
add_action( 'admin_enqueue_scripts', 'Wizardai_enqueue_styles' );
wp_enqueue_style('bootstrap4', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css');
wp_enqueue_script( 'boot1','https://code.jquery.com/jquery-3.3.1.slim.min.js');
wp_enqueue_script( 'boot2','https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js');
wp_enqueue_script( 'boot3','https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js');

function wizardai_enqueue_scripts() {
    wp_enqueue_script(
        'wizardai-script',
        plugins_url( 'wizardai-scripts.js', __FILE__ ),
        array( 'jquery' ), 
        '1.0',
        true
    );
}
add_action( 'admin_enqueue_scripts', 'wizardai_enqueue_scripts' ); 


?>